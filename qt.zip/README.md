Auto Machine Learning Model Generator QT version 0.1
